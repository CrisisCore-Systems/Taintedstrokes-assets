Formerly Functional — SVG Print Kit (back, chest-sigil, sleeve). Convert text to outlines if your RIP requires.
